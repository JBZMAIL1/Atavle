# Stable Diffusion Inpainting App (.app style)

To run this application:

1. Make sure you have Python 3.9 or newer installed.
2. Open a terminal and run:

   pip install torch torchvision diffusers gradio Pillow

3. Then launch the app with:

   python inpainting_app.py

This will open a mobile-optimized inpainting UI in your browser (usually at http://localhost:7860).
