#!/usr/bin/env python3
import gradio as gr
import torch
from diffusers import StableDiffusionInpaintPipeline
from PIL import Image
import os
import tempfile
from typing import List
from concurrent.futures import ThreadPoolExecutor

def load_pipeline() -> StableDiffusionInpaintPipeline:
    pipe = StableDiffusionInpaintPipeline.from_pretrained(
        "stabilityai/stable-diffusion-2-inpainting",
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    )
    pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
    pipe.safety_checker = None
    return pipe

pipe = load_pipeline()

def inpaint_image(image: Image, mask: Image, prompt: str) -> Image:
    with torch.inference_mode():
        output = pipe(
            prompt=[prompt],
            image=[image],
            mask_image=[mask],
            num_inference_steps=50,
            guidance_scale=7.5,
        ).images[0]
    return output

def inpaint_batch(images: List[Image], masks: List[Image], prompt: str, batch_size: int) -> List[str]:
    if not images or not masks or len(images) != len(masks):
        raise ValueError("Upload same number of images and masks.")
    if batch_size > 40:
        raise ValueError("Batch size must not exceed 40.")
    results = []
    with ThreadPoolExecutor() as executor:
        futures = [executor.submit(inpaint_image, img, msk, prompt) for img, msk in zip(images, masks)]
        for future in futures:
            results.append(future.result())
    temp_dir = tempfile.mkdtemp()
    paths = [os.path.join(temp_dir, f"inpainted_{i+1}.png") for i in range(len(results))]
    for img, path in zip(results, paths):
        img.save(path)
    return paths

with gr.Blocks(title="Mobile-Friendly Stable Diffusion Inpainting") as demo:
    gr.Markdown("## 🖼️ Stable Diffusion Inpainting (Mobile-Friendly)\nUpload up to 40 images & masks. Enter a prompt and tap **Inpaint**.")

    with gr.Column():
        images = gr.File(label="📂 Input Images", file_count="multiple", type="file")
        masks = gr.File(label="🎭 Masks (White = Keep, Black = Inpaint)", file_count="multiple", type="file")
        prompt = gr.Textbox(label="🎯 Prompt", value="realistic photo, high quality", lines=1)
        batch_size = gr.Slider(1, 40, value=4, label="📦 Batch Size", interactive=True).style(width="100%")
        run_btn = gr.Button("🚀 Inpaint Now").style(width="100%")

    output_gallery = gr.Gallery(label="🖼️ Results").style(grid=[2], height="auto")
    download_btn = gr.Files(label="⬇️ Download Inpainted Images")
    status_text = gr.Textbox(label="ℹ️ Status", interactive=False)

    def process_inputs(images, masks, prompt, batch_size):
        try:
            pil_imgs = [Image.open(img.name).convert("RGB") for img in images]
            pil_masks = [Image.open(msk.name).convert("L") for msk in masks]
            results = inpaint_batch(pil_imgs, pil_masks, prompt, int(batch_size))
            return results, results, f"✅ Processed {len(results)} images."
        except Exception as e:
            return [], [], f"❌ Error: {str(e)}"

    run_btn.click(
        fn=process_inputs,
        inputs=[images, masks, prompt, batch_size],
        outputs=[output_gallery, download_btn, status_text]
    )

if __name__ == "__main__":
    demo.launch()
